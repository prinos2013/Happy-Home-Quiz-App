# Happy Home Quiz App — corrected Excel import and scoring

## Files to place in the GitHub Pages root

- `index.html` — corrected question importer and scoring logic.
- `sw.js` — updated service worker cache version and runtime caching for successful CORS-enabled assets.
- `manifest.json` — PWA manifest referencing the correct icon files.
- `logo.png` — school logo used by the app interface.
- `icon-192.png` and `icon-512.png` — PWA installation icons.

Upload all six files together into the same root folder of the GitHub repository. Replace the existing `index.html`, `sw.js`, and `manifest.json` files.

## What was fixed

- Reads real `.xlsx` and `.xls` workbooks through the SheetJS browser library.
- Parses CSV safely, including quoted cells containing commas.
- Matches columns by their headings, so the question, options, answer, class, subject, and timer can be in a different column order.
- Recognizes correct answers entered as `A`–`D`, `Option B`, `1`–`4`, or the exact text of one of the four options.
- Uses the same answer-normalization logic during marking, including for previously saved questions whose `correct` field contains answer text.
- Skips rows with missing question text/options or an answer key it cannot recognize, instead of silently marking every response wrong.
- Increments the service-worker cache version so updated app files replace the older cached version.

## Import notes

The `.xlsx` / `.xls` reader is loaded from the official SheetJS CDN (version 0.20.3). The first Excel import requires that script to load successfully. CSV and TXT imports do not require the Excel reader. The app's service worker also attempts to cache successful CORS-enabled assets for later visits.

Use the app's **Download CSV Template** to get the expected column structure:

`Class, Subject, Question, OptionA, OptionB, OptionC, OptionD, CorrectAnswer, TimerMinutes`

For `CorrectAnswer`, use `A`, `B`, `C`, or `D` where possible. The importer also accepts the exact text of the correct option.

## Existing question-bank entries

The update does not delete existing questions or student results. If a question was imported previously with shifted columns (for example, because its question text contained an unquoted comma), delete that incorrect question-bank entry and import the corrected file again. The new scoring logic can recognize an older answer stored as option text, but it cannot reconstruct option columns that were already shifted during an earlier import.
